#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// Note on Security Implementation:
/// This implementation includes basic security measures appropriate for this assignment.
/// Additional security features could be implemented in a production environment, such as:
/// - Secure memory handling (zeroing out sensitive data)
/// - File permission management
/// - Input sanitization for filenames
/// - Cryptographically secure encryption algorithms instead of XOR

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character with the corresponding character in the key
        // Use modulo to wrap around the key if it's shorter than the source
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    // Validate file size before reading
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        throw std::runtime_error("Unable to open file: " + filename);
    }
    
    auto file_size = file.tellg();
    if (file_size > 10'000'000) { // 10MB limit for example
        throw std::runtime_error("File too large");
    }
    
    file.seekg(0, std::ios::beg);
    std::stringstream buffer;
    buffer << file.rdbuf();
    file.close();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename, std::ios::binary);
    
    if (!file.is_open()) {
        throw std::runtime_error("Unable to create file: " + filename);
    }
    
    // Get current time in UTC
    time_t now = time(nullptr);
    tm timeinfo;
    gmtime_s(&timeinfo, &now);
    
    file << student_name << std::endl;
    file << std::put_time(&timeinfo, "%Y-%m-%d") << std::endl;
    file << key << std::endl;
    file << data;
    
    if (file.fail()) {
        file.close();
        throw std::runtime_error("Failed to write to file: " + filename);
    }
    
    file.close();
}

int main()
{
    try {
        std::cout << "Encyption Decryption Test!" << std::endl;

        // input file format
        // Line 1: <students name>
        // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
        // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
        //  Fire in the hole bowsprit Jack Tar gally holystone sloop grog heave to grapple Sea Legs. Gally hearties case shot crimp spirits pillage galleon chase guns skysail yo-ho-ho. Jury mast coxswain measured fer yer chains man-of-war Privateer yardarm aft handsomely Jolly Roger mutiny.
        //  Hulk coffer doubloon Shiver me timbers long clothes skysail Nelsons folly reef sails Jack Tar Davy Jones' Locker. Splice the main brace ye fathom me bilge water walk the plank bowsprit gun Blimey wench. Parrel Gold Road clap of thunder Shiver me timbers hempen halter yardarm grapple wench bilged on her anchor American Main.
        //  Brigantine coxswain interloper jolly boat heave down cutlass crow's nest wherry dance the hempen jig spirits. Interloper Sea Legs plunder shrouds knave sloop run a shot across the bow Jack Ketch mutiny barkadeer. Heave to gun matey Arr draft jolly boat marooned Cat o'nine tails topsail Blimey.

        const std::string file_name = "inputdatafile.txt";
        const std::string encrypted_file_name = "encrypteddatafile.txt";
        const std::string decrypted_file_name = "decrypteddatafile.txt";
        const std::string source_string = read_file(file_name);
        
        if (source_string.empty()) {
            throw std::runtime_error("Input file is empty");
        }
        
        // Get key from user
        std::string key;
        bool validKey = false;
        
        while (!validKey) {
            std::cout << "Enter encryption key (minimum 4 characters): ";
            std::getline(std::cin, key);
            
            if (key.empty()) {
                std::cout << "Error: Key cannot be empty." << std::endl;
            }
            else if (key.length() < 4) {
                std::cout << "Error: Key must be at least 4 characters long." << std::endl;
            }
            else if (key.find_first_of(" \t\n\r") != std::string::npos) {
                std::cout << "Error: Key cannot contain whitespace." << std::endl;
            }
            else {
                validKey = true;
            }
        }

        std::cout << "Key accepted. Processing..." << std::endl;

        // get the student name from the data file
        const std::string student_name = get_student_name(source_string);

        // encrypt sourceString with key
        const std::string encrypted_string = encrypt_decrypt(source_string, key);

        // save encrypted_string to file
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);

        // decrypt encryptedString with key
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

        // save decrypted_string to file
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);

        std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

        // students submit input file, encrypted file, decrypted file, source code file, and key used
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
}
